//
// Created by Admin on 2025-10-14.
//

#include "algo_enhanced.h"
#include "matrix_tool.h"
#include "algo.h"
#include "permutation.h"
#include <iostream>
#include <cmath>

#include "printing_tool.h"

Algo_enhanced::Algo_enhanced(/* args */){}

Algo_enhanced::~Algo_enhanced(){}


std::tuple<bool,
    Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
    std::string> enhanced_check_equiv_between_asso_lp_matrices_learning(const std::string& algoType, Eigen::SparseMatrix<double>& matrixA,Eigen::SparseMatrix<double>& matrixB,
                                                                                                                std::chrono::microseconds& timeout,
                                                                                                                std::vector<std::vector<int>>&  FailRows,
                                                                                                                std::vector<std::vector<int>>&  FailCols,
                                                                                                                std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash>& learned_wrong_row_corr,
                                                                                                                std::vector<std::tuple<int,int,int,int>>& incom_couples_rows_cols,
                                                                                                                int& number_of_failed_perfect_matching) {


    //std::cout << "enter of enhanced algo" << std::endl;
    // initiate the time compter
    auto start = std::chrono::high_resolution_clock::now();

    Algo_equal algo;
    int numRows = matrixA.rows();

    // initialize the first permutation of rows
    std::vector<int> permutationRows;
    for (int i = 0; i < numRows; ++i) {
        permutationRows.push_back(i);
    }

    // instanciate the recorder of the coefs of proportionality
    std::vector<std::vector<int>> proportCoefs;
    for (int i = 0; i < numRows; ++i) {
        proportCoefs.push_back(std::vector<int>(4,0));
    }

    int numCols = matrixA.cols();


    bool succesPermutRows(true);

    int u(0);



    std::vector<std::tuple<int,int,int,int>> incom_couples_empty;
    std::vector<int> permut_empty;

    int number_of_failed_couple_permut(0);
    bool restart(false);

    while (true) {

        std::cout << "searching of rows permutation" << std::endl;
        //print_matrix(FailRows, "FailRows");
        //print_dict(learned_wrong_row_corr, "learned_wrong_row_corr");
        //print_tuple_4(incom_couples_rows_cols, "incom_couples_rows_cols");
        bool new_permut_rows  =  gen_good_permutation_without_wrong_learned_permutation0(permutationRows,  succesPermutRows, numRows,FailRows,
                                            learned_wrong_row_corr,number_of_failed_couple_permut,number_of_failed_perfect_matching, restart);

        if (restart) {
            Eigen::SparseMatrix<double> nullMatrix;
            return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "unknown-due-to-restart");
        }

        if (new_permut_rows) {
            std::cout << "rows permutation found" << std::endl;
            //print_vector(permutationRows, "permutationRows");
        }

        succesPermutRows = false;

        u = u + 1;
        //std::cout << std::endl;
        //if (u == 14) exit(1);

        if (!new_permut_rows) { //std::cout << "available rows permutations finish" << std::endl;
            break;
        }

        for (int lA = 0; lA < numRows; ++lA) {
            int lB = permutationRows[lA];
                proportCoefs[lB][0] = 1;
                proportCoefs[lB][1] = 1;
                proportCoefs[lB][2] = lB;
                proportCoefs[lB][3] = lA;

        }

        /////////////////////////////////////////////////////////////////////////////////////////////////
        if (algoType == "algo_enhanced") {
            learn_wrong_scaling(proportCoefs,matrixA,matrixB,learned_wrong_row_corr);
        }

        std::vector<int> permutationCols;
        // initialize the first permutation of cols

        for (int i = 0; i < numCols; ++i) {
            permutationCols.push_back(i);
        }

        bool succesPermutCols(true);

        while (true) {


            std::cout << "searching of columns permutation" << std::endl;

            bool new_permut_cols = gen_good_permutation0(permutationCols, succesPermutCols, numCols, FailCols,permutationRows,
                            incom_couples_rows_cols,number_of_failed_couple_permut,number_of_failed_perfect_matching, restart);

            if (restart) {
                Eigen::SparseMatrix<double> nullMatrix;
                return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "unknown-due-to-restart");
            }

            if (new_permut_cols) {
                std::cout << "columns permutation found" << std::endl;
                //print_vector(permutationCols, "permutationCols");
            }

            succesPermutCols = false;

            if (!new_permut_cols) { //std::cout << "available columns permutations finish" << std::endl;
                break;
            }

            int numOfEqualities = 0;
            bool stopNextInnerForLoop = false;
            for (unsigned lA=0; lA<numRows; lA++) {
                for (unsigned cA=0; cA<numCols; cA++) {

                    if (matrixA.coeffRef(lA,cA) != matrixB.coeffRef(permutationRows[lA],permutationCols[cA])) {


                        if (algoType == "algo_enhanced") {
                            if (tuple_is_not_inside({lA,permutationRows[lA],cA,permutationCols[cA]},
                                                                            incom_couples_rows_cols)) incom_couples_rows_cols.emplace_back(lA,permutationRows[lA],
                                                                                                                                                    cA,permutationCols[cA]);
                        }
                        number_of_failed_couple_permut ++;
                        std::cout << "number_of_failed_couple_permut = " << number_of_failed_couple_permut << "================" << std::endl;
                        if (number_of_failed_couple_permut == number_of_failed_perfect_matching) restart = true;

                        if (restart) {
                            Eigen::SparseMatrix<double> nullMatrix;
                            return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "unknown-due-to-restart");
                        }

                    stopNextInnerForLoop = true;
                    break;
                    }
                    numOfEqualities = numOfEqualities + 1;
                }
                if (stopNextInnerForLoop) {
                    //std::cout << "ici " << " numOfEqualities = " << numOfEqualities << std::endl;
                    break;
                }
            }
            if (numOfEqualities == numRows * numCols) {


                std::vector<Eigen::Triplet<double>> tripletListRows;
                for (int lA = 0; lA < numRows; ++lA) {
                    tripletListRows.push_back(Eigen::Triplet<double>(permutationRows[lA], lA,1));
                }
                std::vector<Eigen::Triplet<double>> tripletListCols;
                for (int cA = 0; cA < numCols; ++cA) {
                    tripletListCols.push_back(Eigen::Triplet<double>(cA, permutationCols[cA], 1));

                }
                Eigen::SparseMatrix<double> permutMatrixRows(numRows,numRows);
                Eigen::SparseMatrix<double> permutMatrixCols(numCols,numCols);

                permutMatrixRows.setFromTriplets(tripletListRows.begin(), tripletListRows.end());
                permutMatrixRows.makeCompressed();
                permutMatrixCols.setFromTriplets(tripletListCols.begin(), tripletListCols.end());
                permutMatrixCols.makeCompressed();

                Eigen::SparseMatrix<double> nullMatrix;
                std::tuple<bool,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
                            Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,std::string> result;
                result = std::make_tuple(true,permutMatrixRows,permutMatrixCols,
                     nullMatrix, nullMatrix,"solved-without-timeout");

                std::cout << "Equivalence found ." << std::endl << std::endl;
                return result;
            }

            // Record ending time
            auto end = std::chrono::high_resolution_clock::now();

            // Compute the duration in microseconds
            auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
            if (timeout < duration) {
                Eigen::SparseMatrix<double> nullMatrix;
                return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "unknown-due-to-timeout");
            }
        }

    }

    Eigen::SparseMatrix<double> nullMatrix;
    return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "solved-without-timeout");
}

void update_number_failed_couple_perfects_matching_strategy(int intial_num_failed, int& iteration, std::vector<int>& time_sequence, int& number_failed_perfects_matching) {


        if (log2(iteration + 1) == std::floor(log2(iteration + 1))) {

            number_failed_perfects_matching = intial_num_failed * std::pow(2, std::floor(log2(iteration + 1))-1);
            time_sequence.push_back(number_failed_perfects_matching);

        }
        else {

            number_failed_perfects_matching = time_sequence[iteration-std::pow(2,std::ceil(log2(iteration + 1))-1)];
            time_sequence.push_back(number_failed_perfects_matching);

        }

}

std::tuple<Eigen::SparseMatrix<double>,
std::vector<std::pair<int, int>>,std::vector<std::pair<int, int>>> shuffle_matrix(int& iteration, Eigen::SparseMatrix<double>& matrixA) {

    std::vector<std::pair<int, int>> pairsExchangIndexesRows, pairsExchangIndexesCols;

    if (iteration == 1) return std::make_tuple(matrixA,pairsExchangIndexesRows,pairsExchangIndexesCols);

    int numRows = matrixA.rows();

    int numCols = matrixA.cols();

    pairsExchangIndexesRows = gen_pairs_exchang_indexes(numRows, 0);
    pairsExchangIndexesCols = gen_pairs_exchang_indexes(numCols, numCols - 1);

    Eigen::SparseMatrix<double> shuffledRowsA =  permut_rows_or_cols_matrix(true, matrixA, pairsExchangIndexesRows);
    Eigen::SparseMatrix<double> shuffledMatrixA =  permut_rows_or_cols_matrix(false, shuffledRowsA, pairsExchangIndexesCols);
    return std::make_tuple(shuffledMatrixA, pairsExchangIndexesRows,pairsExchangIndexesCols)  ;
}

void  update_fail_rows_or_columns( std::vector<std::pair<int, int>>& pairsExchangIndexesRowsA,
                                   std::vector<std::pair<int, int>>& pairsExchangIndexesRowsB,
                                   std::vector<std::vector<int>>& FailRows) {
    std::vector<std::vector<int>> FailRowsCop = FailRows;

    for (int i = 0; i < pairsExchangIndexesRowsA.size(); ++i) {
        for (int k = 0; k < FailRowsCop.size(); ++k) {
            if (pairsExchangIndexesRowsA[i].first == k) {
                int j = pairsExchangIndexesRowsA[i].second;
                FailRows[j] = FailRowsCop[k];
                FailRows[k] = FailRowsCop[j];
            }
            else {
                if (pairsExchangIndexesRowsA[i].second == k) {
                    int j = pairsExchangIndexesRowsA[i].first;
                    FailRows[j] = FailRowsCop[k];
                    FailRows[k] = FailRowsCop[j];
                }
            }
        }
    }

    for (int i = 0; i < pairsExchangIndexesRowsB.size(); ++i) {
        for (int k = 0; k < FailRows.size(); ++k) {
            for (int l = 0; l < FailRows[k].size(); ++l) {
                if (pairsExchangIndexesRowsB[i].first == FailRows[k][l]) {
                    int j = pairsExchangIndexesRowsB[i].second;
                    FailRows[k][l] = j;
                }
                else {
                    if (pairsExchangIndexesRowsB[i].second == FailRows[k][l]) {
                        int j = pairsExchangIndexesRowsB[i].first;
                        FailRows[k][l] = j;
                    }
                }
            }
        }
    }
}

void update_learned_wrong_row_corr(std::vector<std::pair<int, int>>& pairsExchangIndexesRowsA,
                                   std::vector<std::pair<int, int>>& pairsExchangIndexesRowsB,
                                   std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash>& learned_wrong_row_corr) {


    std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash> learned_wrong_row_corrCp;

    for (const auto& pairs_rows : learned_wrong_row_corr) {

        //std::cout << "enter of first loop for" << std::endl;

        // Update the key pairs_rows.first
        std::pair<int,int> new_key_pair;

        bool first_index_new_key_pair_is_updated = false ;
        bool second_index_new_key_pair_is_updated = false ;

        for (int i = 0; i < pairsExchangIndexesRowsA.size(); ++i) {

            // Update the first component of the key pairs_rows.first
            if (pairsExchangIndexesRowsA[i].first == pairs_rows.first.first) {

                new_key_pair.first = pairsExchangIndexesRowsA[i].second;
                first_index_new_key_pair_is_updated = true ;
                break;

            }
            if (pairsExchangIndexesRowsA[i].second == pairs_rows.first.first) {

                new_key_pair.first = pairsExchangIndexesRowsA[i].first;
                first_index_new_key_pair_is_updated = true ;
                break;
            }
        }
        if (!first_index_new_key_pair_is_updated) new_key_pair.first = pairs_rows.first.first;
        for (int i = 0; i < pairsExchangIndexesRowsB.size(); ++i) {
            // Update the first component of the key pairs_rows.first
            if (pairsExchangIndexesRowsB[i].first == pairs_rows.first.second) {

                new_key_pair.second = pairsExchangIndexesRowsB[i].second;
                second_index_new_key_pair_is_updated = true ;
                break;

            }
            if (pairsExchangIndexesRowsB[i].second == pairs_rows.first.second) {

                new_key_pair.second = pairsExchangIndexesRowsB[i].first;
                second_index_new_key_pair_is_updated = true ;
                break;
            }
        }
        if (!second_index_new_key_pair_is_updated) new_key_pair.second = pairs_rows.first.second;
        std::vector<std::pair<int,int>> pairsIndex;

        learned_wrong_row_corrCp[new_key_pair] = pairsIndex ;

        // Update the value pairs_rows.second
        for (int j = 0; j < pairs_rows.second.size(); ++j) {

            // Update the value pairs_rows.second[j]
            std::pair<int,int> new_val_pair = pairs_rows.second[j];

            bool first_index_new_val_pair_is_updated = false ;
            bool second_index_new_val_pair_is_updated = false ;

            for (int i = 0; i < pairsExchangIndexesRowsA.size(); ++i) {

                // Update the first component of the value pairs_rows.second[j]
                if (pairsExchangIndexesRowsA[i].first == pairs_rows.second[j].first) {

                    new_val_pair.first = pairsExchangIndexesRowsA[i].second;
                    first_index_new_val_pair_is_updated = true ;
                    break;
                }
                if (pairsExchangIndexesRowsA[i].second == pairs_rows.second[j].first) {

                    new_val_pair.first = pairsExchangIndexesRowsA[i].first;
                    first_index_new_val_pair_is_updated = true ;
                    break;
                }
            }
            if (!first_index_new_val_pair_is_updated) new_val_pair.first = pairs_rows.second[j].first ;
            for (int i = 0; i < pairsExchangIndexesRowsB.size(); ++i) {

                // Update the first component of the value pairs_rows.second[j]
                if (pairsExchangIndexesRowsB[i].first == pairs_rows.second[j].second) {

                    new_val_pair.second = pairsExchangIndexesRowsB[i].second;
                    second_index_new_val_pair_is_updated = true ;
                    break;
                }
                if (pairsExchangIndexesRowsB[i].second == pairs_rows.second[j].second) {

                    new_val_pair.second = pairsExchangIndexesRowsB[i].first;
                    second_index_new_val_pair_is_updated = true ;
                    break;
                }
            }
            if (!second_index_new_val_pair_is_updated) new_val_pair.second = pairs_rows.second[j].second ;
            learned_wrong_row_corrCp[new_key_pair].push_back(new_val_pair);
        }
    }
    //print_dict(learned_wrong_row_corr,"learned_wrong_row_corr0");
    //print_dict(learned_wrong_row_corrCp,"learned_wrong_row_corrCp0");
    learned_wrong_row_corr = std::move(learned_wrong_row_corrCp);
    //print_dict(learned_wrong_row_corrCp,"learned_wrong_row_corrCp1");
    //print_dict(learned_wrong_row_corr,"learned_wrong_row_corr1");
}

void update_incom_couples_rows_cols(std::vector<std::pair<int, int>>& pairsExchangIndexesRowsA,
                     std::vector<std::pair<int, int>>& pairsExchangIndexesColsA,
                     std::vector<std::pair<int, int>>& pairsExchangIndexesRowsB,
                     std::vector<std::pair<int, int>>& pairsExchangIndexesColsB,
                     std::vector<std::tuple<int,int,int,int>>& incom_couples_rows_cols) {


    for (int i = 0; i < incom_couples_rows_cols.size(); ++i) {
        for (int j = 0; j < pairsExchangIndexesRowsA.size(); ++j) {

            if (pairsExchangIndexesRowsA[j].first == std::get<0>(incom_couples_rows_cols[i])) {
                std::get<0>(incom_couples_rows_cols[i]) = pairsExchangIndexesRowsA[j].second;
            }
            else {
                if (pairsExchangIndexesRowsA[j].second == std::get<0>(incom_couples_rows_cols[i])) {
                    std::get<0>(incom_couples_rows_cols[i]) = pairsExchangIndexesRowsA[j].first;
                }
            }
        }
        for (int j = 0; j < pairsExchangIndexesRowsB.size(); ++j) {

            if (pairsExchangIndexesRowsB[j].first == std::get<1>(incom_couples_rows_cols[i])) {
                std::get<1>(incom_couples_rows_cols[i]) = pairsExchangIndexesRowsB[j].second;
            }
            else {
                if (pairsExchangIndexesRowsB[j].second == std::get<1>(incom_couples_rows_cols[i])) {
                    std::get<1>(incom_couples_rows_cols[i]) = pairsExchangIndexesRowsB[j].first;
                }
            }
        }
        for (int j = 0; j < pairsExchangIndexesColsA.size(); ++j) {

            if (pairsExchangIndexesColsA[j].first == std::get<2>(incom_couples_rows_cols[i])) {
                std::get<2>(incom_couples_rows_cols[i]) = pairsExchangIndexesColsA[j].second;
            }
            else {
                if (pairsExchangIndexesColsA[j].second == std::get<2>(incom_couples_rows_cols[i])) {
                    std::get<2>(incom_couples_rows_cols[i]) = pairsExchangIndexesColsA[j].first;
                }
            }
        }
        for (int j = 0; j < pairsExchangIndexesColsB.size(); ++j) {

            if (pairsExchangIndexesColsB[j].first == std::get<3>(incom_couples_rows_cols[i])) {
                std::get<3>(incom_couples_rows_cols[i]) = pairsExchangIndexesColsB[j].second;
            }
            else {
                if (pairsExchangIndexesColsB[j].second == std::get<3>(incom_couples_rows_cols[i])) {
                    std::get<3>(incom_couples_rows_cols[i]) = pairsExchangIndexesColsB[j].first;
                }
            }
        }
    }
}

std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash> update_learning(std::vector<std::pair<int, int>>& pairsExchangIndexesRowsA,
                     std::vector<std::pair<int, int>>& pairsExchangIndexesColsA,
                     std::vector<std::pair<int, int>>& pairsExchangIndexesRowsB,
                     std::vector<std::pair<int, int>>& pairsExchangIndexesColsB,
                     std::vector<std::vector<int>>& FailRows,
                     std::vector<std::vector<int>>& FailCols,
                     std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash>& learned_wrong_row_corr,
                     std::vector<std::tuple<int,int,int,int>>& incom_couples_rows_cols) {

    update_fail_rows_or_columns( pairsExchangIndexesRowsA,pairsExchangIndexesRowsB,FailRows);

    update_fail_rows_or_columns( pairsExchangIndexesColsA,pairsExchangIndexesColsB,FailCols);

    //std::cout << "finish of update_fail_rows_or_columns 2 " << std::endl;

    update_learned_wrong_row_corr(pairsExchangIndexesRowsA,pairsExchangIndexesRowsB,learned_wrong_row_corr);

    //std::cout << "finish of update_learned_wrong_row_corr  " << std::endl;

    update_incom_couples_rows_cols(pairsExchangIndexesRowsA,pairsExchangIndexesColsA,
                                   pairsExchangIndexesRowsB,pairsExchangIndexesColsB,
                                   incom_couples_rows_cols);

    //std::cout << "finish of update_incom_couples_rows_cols " << std::endl;

return learned_wrong_row_corr;
}

std::tuple<bool,
    Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
std::string> Algo_enhanced::luby_learning(int intial_num_failed, const std::string& algoType, Eigen::SparseMatrix<double>& matrixA,Eigen::SparseMatrix<double>& matrixB,
                                                    Eigen::SparseMatrix<double>& matrixLowerBoundsA, Eigen::SparseMatrix<double>& matrixLowerBoundsB,
                                                    Eigen::SparseMatrix<double>& matrixUpperBoundsA, Eigen::SparseMatrix<double>& matrixUpperBoundsB,
                                                                                                            std::chrono::microseconds timeout) {

    std::cout << "running of luby Algorithm" << std::endl;
    // initiate the time compter
    auto start = std::chrono::high_resolution_clock::now();

    Algo_equal algo;
    int numRows = matrixA.rows();

    int numCols = matrixA.cols();

    Eigen::SparseMatrix<double> sortedOnColsMatrixA = generate_sorted_rows_cols_based_value_sparse_matrix(false, matrixA);
    Eigen::SparseMatrix<double> sortedOnColsMatrixB = generate_sorted_rows_cols_based_value_sparse_matrix(false, matrixB);

    // Get correspondances between same sets of coefficients of columns of A and  B
    std::vector<std::vector<int>> corrColA0 = algo.get_set_indexes_corr_cols_by_bounds_matrices(numCols, matrixLowerBoundsA, matrixLowerBoundsB);
    std::vector<std::vector<int>> corrColA1 = algo.get_set_indexes_corr_cols_by_bounds_matrices(numCols, matrixUpperBoundsA, matrixUpperBoundsB);
    std::vector<std::vector<int>> corrColA = algo.get_set_indexes_corr(false, numCols, matrixA, matrixB);

    for (int i = 0; i < numCols; ++i) {
        std::vector<size_t> corrCols = {corrColA0[i].size(),  corrColA1[i].size(), corrColA[i].size()};
        int min_ind =  get_min_index(corrCols);
        std::vector<std::vector<int>> corrColsSet = {corrColA0[i],  corrColA1[i], corrColA[i]};
        corrColA[i] = corrColsSet[min_ind];
    }

    Eigen::SparseMatrix<double> sortedOnRowsMatrixA = generate_sorted_rows_cols_based_value_sparse_matrix(true, matrixA);
    Eigen::SparseMatrix<double> sortedOnRowsMatrixB = generate_sorted_rows_cols_based_value_sparse_matrix(true, matrixB);

    std::vector<std::vector<int>> corrRowA = algo.get_set_indexes_corr(true, numRows, matrixA, matrixB);

    for (const auto & i : corrRowA) {
        if (i.empty()) {
            Eigen::SparseMatrix<double> nullMatrix;
            return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "solved-without-timeout");
        }
    }

    std::vector<std::vector<int>> FailRows;
    for (int i = 0; i < numRows; ++i) {
        std::vector<int> uncompatibleRowsWith_i;
        FailRows.push_back(uncompatibleRowsWith_i);
    }
    initialize_failing_set(FailRows, corrRowA);

    std::vector<std::vector<int>> FailCols;
    for (int i = 0; i < numCols; ++i) {
        std::vector<int> uncompatibleColsWith_i;
        FailCols.push_back(uncompatibleColsWith_i);
    }

    for (const auto & i : corrColA) {
        if (i.empty()) {
            Eigen::SparseMatrix<double> nullMatrix;
            return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "solved-without-timeout");
        }
    }

    initialize_failing_set(FailCols, corrColA);
    //print_matrix(FailCols, "FailCols");

    // instanciate the recorder of learned wrong scaling
    std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash> learned_wrong_row_corr;

    std::vector<std::tuple<int,int,int,int>>  incom_couples_rows_cols;


    // Record ending time
    auto end = std::chrono::high_resolution_clock::now();

    // Compute the duration in microseconds
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);


    std::tuple<bool,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
                    Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,std::string> result;
    std::get<0>(result) = false;

    Eigen::SparseMatrix<double> shuffledMatrixA = matrixA;
    Eigen::SparseMatrix<double> shuffledMatrixB = matrixB;
    //std::cout << "shuffledMatrixB = " << shuffledMatrixB <<  std::endl;

    // Initialize the luby algo
    int number_failed_perfects_matching(0);
    int iteration(1);
    std::vector<int> time_sequence;

    std::tuple<Eigen::SparseMatrix<double>,
    std::vector<std::pair<int, int>>,std::vector<std::pair<int, int>>> shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsA;

    std::tuple<Eigen::SparseMatrix<double>,
    std::vector<std::pair<int, int>>,std::vector<std::pair<int, int>>> shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsB;


    while (timeout >= duration && !(std::get<0>(result))) {

        //std::cout << "ici00" << std::endl;

        update_number_failed_couple_perfects_matching_strategy(intial_num_failed, iteration, time_sequence, number_failed_perfects_matching);

        std::string iteration_string ;
        if (iteration == 1) iteration_string = "Intialization" ;
        else iteration_string = "Restart ";

        std::cout << iteration_string << iteration-1 << ", " << "number_failed_perfects_matching = " << number_failed_perfects_matching <<"----------------------------" <<  std::endl;
        print_vector(time_sequence, "time_sequence");
        if (iteration > 1) {

            //std::cout << "ici0" << std::endl;
            shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsA = shuffle_matrix(iteration,shuffledMatrixA);
            shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsB = shuffle_matrix(iteration,shuffledMatrixB);
            //std::cout << "ici1" << std::endl;

            shuffledMatrixA = std::get<0>(shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsA);
            //std::cout << "shuffledMatrixA = " << shuffledMatrixA <<  std::endl;
            std::vector<std::pair<int, int>> pairsExchangIndexesRowsA = std::get<1>(shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsA);
            std::vector<std::pair<int, int>> pairsExchangIndexesColsA = std::get<2>(shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsA);

            //print_pair(pairsExchangIndexesRowsA,"pairsExchangIndexesRowsA");

            //std::cout << "ici2" << std::endl;
            shuffledMatrixB = std::get<0>(shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsB);
            //std::cout << "shuffledMatrixB = " << shuffledMatrixB <<  std::endl;
            std::vector<std::pair<int, int>> pairsExchangIndexesRowsB = std::get<1>(shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsB);
            std::vector<std::pair<int, int>> pairsExchangIndexesColsB = std::get<2>(shuffledMatrix_pairsExchangIndexesRows_pairsExchangIndexesColsB);
            //std::cout << "just to start update learning " << std::endl;
            //print_pair(pairsExchangIndexesRowsB,"pairsExchangIndexesRowsB");

            update_learning(pairsExchangIndexesRowsA,pairsExchangIndexesColsA,
                            pairsExchangIndexesRowsB,pairsExchangIndexesColsB,
                                                        FailRows,FailCols,
                                                        learned_wrong_row_corr,
                                                        incom_couples_rows_cols);
            std::cout << "finish of update learning" << std::endl;
        }

        result = enhanced_check_equiv_between_asso_lp_matrices_learning(algoType, shuffledMatrixA,
                                                                                  shuffledMatrixB,
                                                                                  timeout,
                                                                                  FailRows,FailCols,
                                                                                learned_wrong_row_corr,
                                                                                incom_couples_rows_cols,
                                                                                number_failed_perfects_matching);
        iteration ++;

        // Record ending time
        auto end = std::chrono::high_resolution_clock::now();
        // Compute the duration in microseconds
        duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    }
    return result;
}