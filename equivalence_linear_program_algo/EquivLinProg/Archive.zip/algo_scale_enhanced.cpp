//
// Created by Admin on 2025-10-14.
//

#include "algo_scale_enhanced.h"
#include "algo_scale.h"
#include "algo.h"
#include "permutation.h"
#include "matrix_tool.h"
#include "printing_tool.h"
#include <iostream>

Algo_scale_enhanced::Algo_scale_enhanced(/* args */){}

Algo_scale_enhanced::~Algo_scale_enhanced(){}


std::vector<std::vector<int>> initialize_failing_cols(Eigen::SparseMatrix<double>& matrixA,
                                                  Eigen::SparseMatrix<double>& matrixLowerBoundsA, Eigen::SparseMatrix<double>& matrixLowerBoundsB,
                                                  Eigen::SparseMatrix<double>& matrixUpperBoundsA, Eigen::SparseMatrix<double>& matrixUpperBoundsB,Algo_equal algo) {

    int numCols = matrixA.cols();

    // Get correspondances between same sets of coefficients of columns of A and  B
    std::vector<std::vector<int>> corrColA0 = algo.get_set_indexes_corr_cols_by_bounds_matrices(numCols, matrixLowerBoundsA, matrixLowerBoundsB);
    std::vector<std::vector<int>> corrColA = algo.get_set_indexes_corr_cols_by_bounds_matrices(numCols, matrixUpperBoundsA, matrixUpperBoundsB);


    for (int i = 0; i < numCols; ++i) {
        std::vector<size_t> corrCols = {corrColA0[i].size(),  corrColA[i].size()};
        int min_ind =  get_min_index(corrCols);
        std::vector<std::vector<int>> corrColsSet = {corrColA0[i],  corrColA[i]};
        corrColA[i] = corrColsSet[min_ind];
    }
    std::vector<std::vector<int>> FailCols;
    for (int i = 0; i < numCols; ++i) {
        std::vector<int> uncompatibleColsWith_i;
        FailCols.push_back(uncompatibleColsWith_i);
    }

    initialize_failing_set(FailCols, corrColA);
    return FailCols;
}


std::tuple<bool,
    Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
    std::string> Algo_scale_enhanced::enhanced_check_equiv_between_asso_lp_scaled_matrices(Eigen::SparseMatrix<double>& matrixA,Eigen::SparseMatrix<double>& matrixB,
                                                                                            Eigen::SparseMatrix<double>& matrixLowerBoundsA, Eigen::SparseMatrix<double>& matrixLowerBoundsB,
                                                                                            Eigen::SparseMatrix<double>& matrixUpperBoundsA, Eigen::SparseMatrix<double>& matrixUpperBoundsB,
                                                                                                                std::chrono::microseconds timeout) {

    // initiate the time compter
    auto start = std::chrono::high_resolution_clock::now();

    Algo_equal algo;
    Algo_scale algo_scale;
    int numRows = matrixA.rows();

    // initialize the first permutation of rows
    std::vector<int> permutationRows;
    for (int i = 0; i < numRows; ++i) {
        permutationRows.push_back(i);
    }

    // instanciate the recorder of the coefs of proportionality
    std::vector<std::vector<int>> proportCoefs;
    for (int i = 0; i < numRows; ++i) {
        proportCoefs.push_back(std::vector<int>(4,0));
    }

    Eigen::SparseMatrix<double> sortedOnRowsMatrixA = generate_sorted_rows_cols_based_value_sparse_matrix(true, matrixA);
    Eigen::SparseMatrix<double> sortedOnRowsMatrixB = generate_sorted_rows_cols_based_value_sparse_matrix(true, matrixB);


    std::vector<std::vector<int>> FailRows;
    for (int i = 0; i < numRows; ++i) {
        std::vector<int> uncompatibleRowsWith_i;
        FailRows.push_back(uncompatibleRowsWith_i);
    }
    int lAOfPermutation = -1;

    std::vector<std::tuple<int,int,int,int>>  incom_couples_rows_cols;

    std::vector<int> permutationRowsSol = {0, 1, 2, 3, 4, 5, 6, 17, 8, 9, 10, 11, 12, 13, 14, 15, 16, 7, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33};
    //permutationRows = {0, 1, 2, 3, 4, 5, 6, 17, 8, 9, 10, 11, 12, 13, 14, 15, 16, 7, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33};


    int u(0);

    while (true) {

        std::cout << "Search for permutationRows " << u << std::endl;

        u ++;

        //bool new_permut_rows = permut_by_avoiding_wrong_learned_permutations(permutationRows, lAOfPermutation, numRows, FailRows);
        bool new_permut_rows(false);

        std::cout << "ici1 lAOfPermutation = " << lAOfPermutation << " new_permut_rows = " << new_permut_rows <<   std::endl;
        print_vector(permutationRows, "permutationRows");

        if (!new_permut_rows) break;
        std::cout << "ici2" << std::endl;

        // reinitiate if the scaling exist between A and B
        bool scaling_exist_between_rowsA_B = false;
        for (int lA = 0; lA < numRows; ++lA) {
            int lB = permutationRows[lA];
            std::tuple<bool,int,int> test_rows_passed = algo_scale.check_scaling_sets(true, sparse_row_col(true, sortedOnRowsMatrixA,lA),
                                                                                sparse_row_col(true, sortedOnRowsMatrixB,lB));
            if (std::get<0>(test_rows_passed)){
                scaling_exist_between_rowsA_B = true;
                proportCoefs[lB][0] = std::get<1>(test_rows_passed);
                proportCoefs[lB][1] = std::get<2>(test_rows_passed);
                proportCoefs[lB][2] = lB;
                proportCoefs[lB][3] = lA;
            }
            else {
                scaling_exist_between_rowsA_B = false;
                FailRows[lA].push_back(lB);
                lAOfPermutation = lA;
                std::cout << "hhhh" << std::endl;
                break;
            }
        }
        if (scaling_exist_between_rowsA_B) {
            /////////////////////////////////////////////////////////////////////////////////////////////////
            std::vector<std::vector<int>> FailCols = initialize_failing_cols(matrixA,matrixLowerBoundsA, matrixLowerBoundsB,
                                                                                        matrixUpperBoundsA, matrixUpperBoundsB,algo);
            int numCols = matrixA.cols();

            // initialize the first permutation of cols
            std::vector<int> permutationCols;
            for (int i = 0; i < numCols; ++i) {
                permutationCols.push_back(i);
            }
            std::pair<Eigen::SparseMatrix<double>,
                          Eigen::SparseMatrix<double>> scaledAB = algo_scale.generate_scaled_rows_sparse_matrix(matrixA, matrixB,proportCoefs);
            Eigen::SparseMatrix<double> sortedOnColsScaledMatrixA = generate_sorted_rows_cols_based_value_sparse_matrix(false, scaledAB.first);
            Eigen::SparseMatrix<double> sortedOnColsScaledMatrixB = generate_sorted_rows_cols_based_value_sparse_matrix(false, scaledAB.second);

            int cAOfPermutation = -1;

            //permutationCols = {0, 31, 5, 3, 4, 2, 30, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 6, 1, 32};
            //                  {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32}

            while (true) {

                if (vectors_are_equal(permutationRowsSol,permutationRows)) {
                    print_vector(permutationCols, "permutationCols0");
                }
                bool new_permut_cols = permut_by_avoiding_wrong_learned_permutations(permutationCols, cAOfPermutation, numCols, FailCols);
                print_vector(permutationCols, "permutationCols00");
                if (vectors_are_equal(permutationRowsSol,permutationRows)) {
                    print_matrix(FailCols, "FailCols");
                    std::cout << "new_permut_cols = " << new_permut_cols << std::endl;
                }
                if (!new_permut_cols) break;

                new_permut_cols = gen_permutation_without_incomp(permutationCols,  numCols, FailCols,permutationRows, incom_couples_rows_cols);

                print_tuple_4(incom_couples_rows_cols, "incom_couples_rows_cols");

                if (!new_permut_cols) break;

                // reinitiate if the scaling exist between A and B
                bool scaling_exist_between_colsA_B = false;
                for (int cA = 0; cA < numCols; ++cA) {
                    int cB = permutationCols[cA];
                    bool test_col_passed = algo.chek_equal_set(false, sparse_row_col(false, sortedOnColsScaledMatrixA,cA),
                                                                                sparse_row_col(false, sortedOnColsScaledMatrixB,cB));

                    if (test_col_passed){

                        scaling_exist_between_colsA_B = true;
                    }
                    else {

                        scaling_exist_between_colsA_B = false;
                        if (!is_inside(cB, FailCols[cA])) FailCols[cA].push_back(cB);
                        cAOfPermutation = cA;
                        break;
                    }
                }
                if (scaling_exist_between_colsA_B) {

                    int numOfEqualities = 0;
                    bool stopNextInnerForLoop = false;
                    for (unsigned lA=0; lA<numRows; lA++) {
                        for (unsigned cA=0; cA<numCols; cA++) {

                            if (scaledAB.first.coeffRef(lA,cA) != scaledAB.second.coeffRef(permutationRows[lA],permutationCols[cA])) {
                                if (tuple_is_not_inside({lA,permutationRows[lA],cA,permutationCols[cA]},
                                                                                incom_couples_rows_cols)) incom_couples_rows_cols.emplace_back(lA,permutationRows[lA],
                                                                                                                                                        cA,permutationCols[cA]);

                                stopNextInnerForLoop = true;
                                break;
                            }
                            numOfEqualities = numOfEqualities + 1;
                        }
                        if (stopNextInnerForLoop) {

                            break;
                        }
                    }
                    if (numOfEqualities == numRows * numCols) {

                        std::vector<Eigen::Triplet<double>> tripletListRows;
                        for (int lA = 0; lA < numRows; ++lA) {
                            tripletListRows.push_back(Eigen::Triplet<double>(permutationRows[lA], lA,1));
                        }
                        std::vector<Eigen::Triplet<double>> tripletListCols;
                        for (int cA = 0; cA < numCols; ++cA) {
                            tripletListCols.push_back(Eigen::Triplet<double>(cA, permutationCols[cA], 1));

                        }
                        Eigen::SparseMatrix<double> permutMatrixRows(numRows,numRows);
                        Eigen::SparseMatrix<double> permutMatrixCols(numCols,numCols);

                        permutMatrixRows.setFromTriplets(tripletListRows.begin(), tripletListRows.end());
                        permutMatrixRows.makeCompressed();
                        permutMatrixCols.setFromTriplets(tripletListCols.begin(), tripletListCols.end());
                        permutMatrixCols.makeCompressed();

                        std::tuple<bool,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
                                        Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,std::string> result;
                        result = std::make_tuple(true,permutMatrixRows,permutMatrixCols,
                                 scaledAB.first, scaledAB.second,"solved-without-timeout");

                        std::cout << "Equivalence found ." << std::endl << std::endl;
                        return result;
                    }
                }
                // Record ending time
                auto end = std::chrono::high_resolution_clock::now();

                // Compute the duration in microseconds
                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                if (timeout < duration) {
                    Eigen::SparseMatrix<double> nullMatrix;
                    return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "unknown-due-to-timeout");
                }
            }
            gen_next_permut_greater_in_lexicographic_order(false, permutationRows);
            lAOfPermutation = -1;
            std::cout << "yesss" << std::endl;
        }
    }

    Eigen::SparseMatrix<double> nullMatrix;
    return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "solved-without-timeout");

}