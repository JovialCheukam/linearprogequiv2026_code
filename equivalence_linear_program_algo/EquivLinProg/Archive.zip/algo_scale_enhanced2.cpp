//
// Created by Admin on 2025-10-14.
//

#include "algo_scale_enhanced2.h"
#include "algo_scale_enhanced.h"
#include "algo_scale.h"
#include "algo.h"
#include "permutation.h"
#include "matrix_tool.h"
#include <iostream>

#include "printing_tool.h"


Algo_scale_enhanced2::Algo_scale_enhanced2(/* args */){}

Algo_scale_enhanced2::~Algo_scale_enhanced2(){}


bool a_couple_is_inside(std::pair<int,int> pair, std::vector<std::pair<int,int>>& list_of_pairs) {

    for (int i = 1; i < list_of_pairs.size(); ++i) {
        if (pair.first == list_of_pairs[i].first && pair.second == list_of_pairs[i].second) return true;
    }
    return false;
}

bool learn_wrong_scaling(std::vector<std::vector<int>>& proportCoefs,
                                                            Eigen::SparseMatrix<double>& matrixA,Eigen::SparseMatrix<double>& matrixB,
                                                            std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash>& learned_wrong_scaling) {
    int num_lines = proportCoefs.size();

    bool is_same_permutation(true);
    // normalize the matrices A and B as equal by permutations of
    // lines and columns using the cross products property of proportions

    for (int i = 0; i < num_lines-1; ++i) {
        Eigen::SparseMatrix<double> row1 = sparse_row_col(true,matrixA,proportCoefs[i][3]) * proportCoefs[i][1];
        Eigen::SparseMatrix<double> row2_corr1 = sparse_row_col(true,matrixB,proportCoefs[i][2]) * proportCoefs[i][0];
        //print_matrix(proportCoefs, "proportCoefs");
        //std::cout << "rowA1 = " << proportCoefs[i][3] << " rowB1 = " << proportCoefs[i][2] << std::endl;


        for (int j = i+1; j < num_lines; ++j) {

            // normalize the matrices A and B as equal by permutations of
            // lines and columns using the cross products property of proportions
            Eigen::SparseMatrix<double> row3 = sparse_row_col(true,matrixA,proportCoefs[j][3]) * proportCoefs[j][1];
            Eigen::SparseMatrix<double> row4_corr3 = sparse_row_col(true,matrixB,proportCoefs[j][2]) * proportCoefs[j][0];

            //std::cout << "rowA2 = " << proportCoefs[j][3] << " rowB2 = " << proportCoefs[j][2] << std::endl;
            std::pair<bool, std::vector<int>> same_permut_i = is_same_permut_for_elts(row1,row2_corr1,row3,row4_corr3);
            //std::cout << "same_permut_i = " << same_permut_i.first << std::endl;

            if (!same_permut_i.first) {
                std::pair key = std::make_pair(proportCoefs[i][3],proportCoefs[i][2]);
                if (!learned_wrong_scaling.count(key)) {
                    learned_wrong_scaling[key].push_back(std::make_pair(proportCoefs[j][3],proportCoefs[j][2]));
                }
                else {
                    if (!a_couple_is_inside({proportCoefs[j][3],proportCoefs[j][2]},learned_wrong_scaling[key])) {
                        learned_wrong_scaling[key].push_back(std::make_pair(proportCoefs[j][3],proportCoefs[j][2]));
                    }
                }
                is_same_permutation = false;
            }
        }
    }
    return is_same_permutation;
}

std::pair<bool,int> is_wrong_scaling(const std::vector<int> &permut_vec, std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash> learned_wrong_scaling) {
    for (const auto& pair : learned_wrong_scaling) {

        int k1 = pair.first.first;
        int k2 = pair.first.second;
        for (int i = 0; i < learned_wrong_scaling[pair.first].size(); ++i) {
            int l1 = learned_wrong_scaling[pair.first].at(i).first;
            int l2 = learned_wrong_scaling[pair.first].at(i).second;
            std::vector<std::pair<int,int>> uncompatibleScalings;
            uncompatibleScalings.push_back(std::make_pair(k1,k2));
            uncompatibleScalings.push_back(std::make_pair(l1,l2));

            // Sort  based on first component of the couple
            std::sort(uncompatibleScalings.begin(), uncompatibleScalings.end(),
                  [](std::pair<int,int> a, std::pair<int,int> b) {
                      return a.first < b.first; // Sort by first component of the couple in ascending order
                  });
            int i1 = uncompatibleScalings[0].first;
            int i2 = uncompatibleScalings[0].second;
            int j1 = uncompatibleScalings[1].first;
            int j2 = uncompatibleScalings[1].second;

            if (permut_vec[i1] == i2 && permut_vec[j1] == j2) {
                    return std::make_pair(true , j1);
            }
        }
    }
    return std::make_pair(false,-1);
}

bool permut_without_wrong_learned_permutation_and_scaling(std::vector<int>& permut_vec, int l_B, int num_lines, std::vector<std::vector<int>>& Fail_k,
    const std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash> & learned_wrong_scaling) {

    //bool new_permut = permut_by_avoiding_wrong_learned_permutations(permut_vec,l_B,num_lines,Fail_k);

    bool new_permut(false);

    if (new_permut) {
        std::pair<bool,int> wrong_scaling_j1 =  is_wrong_scaling(permut_vec,learned_wrong_scaling);

        while (wrong_scaling_j1.first && new_permut) {
            new_permut = permut_by_avoiding_wrong_learned_permutations(permut_vec,wrong_scaling_j1.second,num_lines,Fail_k);

            wrong_scaling_j1 =  is_wrong_scaling(permut_vec,learned_wrong_scaling);
        }
    }
    return new_permut;
}

std::tuple<bool,
    Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
    std::string> Algo_scale_enhanced2::enhanced2_check_equiv_between_asso_lp_scaled_matrices(Eigen::SparseMatrix<double>& matrixA,Eigen::SparseMatrix<double>& matrixB,
                                                                        Eigen::SparseMatrix<double>& matrixLowerBoundsA, Eigen::SparseMatrix<double>& matrixLowerBoundsB,
                                                                        Eigen::SparseMatrix<double>& matrixUpperBoundsA, Eigen::SparseMatrix<double>& matrixUpperBoundsB,
                                                                                                                std::chrono::microseconds timeout) {
    // initiate the time compter
    auto start = std::chrono::high_resolution_clock::now();

    Algo_equal algo;
    Algo_scale algo_scale;
    int numRows = matrixA.rows();

    // initialize the first permutation of rows
    std::vector<int> permutationRows;
    for (int i = 0; i < numRows; ++i) {
        permutationRows.push_back(i);
    }

    // instanciate the recorder of the coefs of proportionality
    std::vector<std::vector<int>> proportCoefs;
    for (int i = 0; i < numRows; ++i) {
        proportCoefs.push_back(std::vector<int>(4,0));
    }

    Eigen::SparseMatrix<double> sortedOnRowsMatrixA = generate_sorted_rows_cols_based_value_sparse_matrix(true, matrixA);
    Eigen::SparseMatrix<double> sortedOnRowsMatrixB = generate_sorted_rows_cols_based_value_sparse_matrix(true, matrixB);


    std::vector<std::vector<int>> FailRows;
    for (int i = 0; i < numRows; ++i) {
        std::vector<int> uncompatibleRowsWith_i;
        FailRows.push_back(uncompatibleRowsWith_i);
    }
    int lAOfPermutation = -1;
    int u(0);

    // instanciate the recorder of learned wrong scaling
    std::unordered_map<std::pair<int,int>, std::vector<std::pair<int,int>>, PairHash> learned_wrong_scaling;
    std::vector<std::tuple<int,int,int,int>>  incom_couples_rows_cols;


    permutationRows = {0, 1, 2, 3, 4, 5, 6, 17, 8, 9, 10, 11, 12, 13, 14, 15, 16, 7, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33};


    while (true) {

        std::cout << "Search for permutationRows " << u << std::endl;

        u ++;

        bool new_permut_rows = permut_without_wrong_learned_permutation_and_scaling(permutationRows, lAOfPermutation, numRows, FailRows, learned_wrong_scaling);

        print_vector(permutationRows, "permutationRows");


        if (!new_permut_rows) break;
        std::vector<std::pair<int,int>> set_of_incom_couples_rows;

        // reinitiate if the scaling exist between A and B
        bool scaling_exist_between_rowsA_B = false;
        for (int lA = 0; lA < numRows; ++lA) {
            int lB = permutationRows[lA];
            std::tuple<bool,int,int> test_rows_passed = algo_scale.check_scaling_sets(true, sparse_row_col(true, sortedOnRowsMatrixA,lA),
                                                                                sparse_row_col(true, sortedOnRowsMatrixB,lB));

            if (std::get<0>(test_rows_passed)){
                scaling_exist_between_rowsA_B = true;
                proportCoefs[lB][0] = std::get<1>(test_rows_passed);
                proportCoefs[lB][1] = std::get<2>(test_rows_passed);
                proportCoefs[lB][2] = lB;
                proportCoefs[lB][3] = lA;
            }
            else {
                scaling_exist_between_rowsA_B = false;
                FailRows[lA].push_back(lB);
                lAOfPermutation = lA;
                break;
            }
        }
        if (scaling_exist_between_rowsA_B) {
            /////////////////////////////////////////////////////////////////////////////////////////////////
            std::vector<std::vector<int>> FailCols = initialize_failing_cols(matrixA,matrixLowerBoundsA, matrixLowerBoundsB,
                                                                                        matrixUpperBoundsA, matrixUpperBoundsB,algo);
            learn_wrong_scaling(proportCoefs,matrixA,matrixB,learned_wrong_scaling);
            print_dict(learned_wrong_scaling, "learned_wrong_scaling");
            int numCols = matrixA.cols();

            std::pair<Eigen::SparseMatrix<double>,
                                      Eigen::SparseMatrix<double>> scaledAB = algo_scale.generate_scaled_rows_sparse_matrix(matrixA, matrixB,proportCoefs);
            Eigen::SparseMatrix<double> sortedOnColsScaledMatrixA = generate_sorted_rows_cols_based_value_sparse_matrix(false, scaledAB.first);
            Eigen::SparseMatrix<double> sortedOnColsScaledMatrixB = generate_sorted_rows_cols_based_value_sparse_matrix(false, scaledAB.second);

            std::vector<int> permutationCols;
            // initialize the first permutation of cols

            for (int i = 0; i < numCols; ++i) {
                    permutationCols.push_back(i);
            }

            int cAOfPermutation = -1;

            //permutationCols = {0, 31, 5, 3, 4, 2, 30, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 6, 1, 32};

            while (true) {

                bool new_permut_cols = permut_by_avoiding_wrong_learned_permutations(permutationCols, cAOfPermutation, numCols, FailCols);

                if (!new_permut_cols) break;

                new_permut_cols = gen_permutation_without_incomp(permutationCols,  numCols, FailCols,permutationRows, incom_couples_rows_cols);
                print_vector(permutationCols, "permutationCols0");

                if (!new_permut_cols) break;

                // reinitiate if the scaling exist between A and B
                bool scaling_exist_between_colsA_B = false;
                for (int cA = 0; cA < numCols; ++cA) {
                    int cB = permutationCols[cA];
                    bool test_col_passed = algo.chek_equal_set(false, sparse_row_col(false, sortedOnColsScaledMatrixA,cA),
                                                                            sparse_row_col(false, sortedOnColsScaledMatrixB,cB));

                    if (test_col_passed){
                        scaling_exist_between_colsA_B = true;
                    }
                    else {
                        scaling_exist_between_colsA_B = false;
                        if (!is_inside(cB, FailCols[cA])) FailCols[cA].push_back(cB);
                        cAOfPermutation = cA;
                        break;
                    }
                }

                if (scaling_exist_between_colsA_B) {


                    int numOfEqualities = 0;
                    bool stopNextInnerForLoop = false;
                    for (unsigned lA=0; lA<numRows; lA++) {
                        for (unsigned cA=0; cA<numCols; cA++) {

                            if (scaledAB.first.coeffRef(lA,cA) != scaledAB.second.coeffRef(permutationRows[lA],permutationCols[cA])) {

                                if (tuple_is_not_inside({lA,permutationRows[lA],cA,permutationCols[cA]},
                                                                                incom_couples_rows_cols)) incom_couples_rows_cols.emplace_back(lA,permutationRows[lA],
                                                                                                                                                        cA,permutationCols[cA]);
                                stopNextInnerForLoop = true;
                                break;
                            }
                            numOfEqualities = numOfEqualities + 1;
                        }
                        if (stopNextInnerForLoop) {
                            break;
                        }
                    }
                    if (numOfEqualities == numRows * numCols) {


                        std::vector<Eigen::Triplet<double>> tripletListRows;
                        for (int lA = 0; lA < numRows; ++lA) {
                            tripletListRows.push_back(Eigen::Triplet<double>(permutationRows[lA], lA,1));
                        }
                        std::vector<Eigen::Triplet<double>> tripletListCols;
                        for (int cA = 0; cA < numCols; ++cA) {
                            tripletListCols.push_back(Eigen::Triplet<double>(cA, permutationCols[cA], 1));
                        }
                        Eigen::SparseMatrix<double> permutMatrixRows(numRows,numRows);
                        Eigen::SparseMatrix<double> permutMatrixCols(numCols,numCols);

                        permutMatrixRows.setFromTriplets(tripletListRows.begin(), tripletListRows.end());
                        permutMatrixRows.makeCompressed();
                        permutMatrixCols.setFromTriplets(tripletListCols.begin(), tripletListCols.end());
                        permutMatrixCols.makeCompressed();

                        std::tuple<bool,Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,
                                    Eigen::SparseMatrix<double>,Eigen::SparseMatrix<double>,std::string> result;
                        result = std::make_tuple(true,permutMatrixRows,permutMatrixCols,
                             scaledAB.first, scaledAB.second,"solved-without-timeout");

                        std::cout << "Equivalence found ." << std::endl << std::endl;
                        return result;
                    }
                }

                // Record ending time
                auto end = std::chrono::high_resolution_clock::now();

                // Compute the duration in microseconds
                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                if (timeout < duration) {
                    Eigen::SparseMatrix<double> nullMatrix;
                    return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "unknown-due-to-timeout");
                }
            }
            gen_next_permut_greater_in_lexicographic_order(false, permutationRows);
            lAOfPermutation = -1;
        }
    }
    Eigen::SparseMatrix<double> nullMatrix;
    return std::make_tuple(false, nullMatrix,nullMatrix,nullMatrix,nullMatrix, "solved-without-timeout");
}
